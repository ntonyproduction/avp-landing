<#
    Installs the fonts Chatterbox needs, for the current user only: Open Sans, the cards'
    typeface, and Noto Color Emoji.
    No administrator rights required. Remove later from Settings > Personalisation > Fonts.

    Why a font is needed at all: when DaVinci Resolve's Text+ meets an emoji it switches to
    the font family "Noto Color Emoji" for that glyph. If no font by that name is installed
    the text node fails -- and the whole comment card goes black. Installing it once fixes
    every emoji. This is Google's COLRv1 (vector) build of the font.

    Resolve's optional font allow-list (Preferences > User > Editing > Text > Display Only
    Specific Fonts) hides every family not named in its text file from Fusion. If that
    setting is on, this script appends "Noto Color Emoji" to the file.

    Then RESTART DaVinci Resolve: it reads the font list when it launches.
#>
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$dir  = Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\Fonts'
$reg  = 'HKCU:\Software\Microsoft\Windows NT\CurrentVersion\Fonts'
New-Item -ItemType Directory -Force -Path $dir | Out-Null
if (-not (Test-Path $reg)) { New-Item -Path $reg -Force | Out-Null }

# Registering a font is two steps: the registry entry makes it permanent, and
# AddFontResource loads it into the current session so apps started from now on see it.
# The Fonts settings page does both when you click Install; skipping the second one leaves
# the font invisible until the next sign-in.
$sig = @'
[DllImport("gdi32.dll", CharSet = CharSet.Unicode)] public static extern int AddFontResourceW(string lpszFilename);
[DllImport("user32.dll")] public static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam, uint fuFlags, uint uTimeout, out IntPtr lpdwResult);
'@
$native = Add-Type -MemberDefinition $sig -Name FontLoad -Namespace AVP -PassThru

$fonts = @{ 'OpenSans.ttf' = 'Open Sans (TrueType)'; 'Noto-COLRv1.ttf' = 'Noto Color Emoji (TrueType)' }
foreach ($file in $fonts.Keys) {
    $src = Join-Path $here $file
    if (-not (Test-Path $src)) { Write-Host "Missing $file next to this script." -ForegroundColor Yellow; continue }
    $dest = Join-Path $dir $file
    # A font already installed, under any file name, is left alone: a second copy would list
    # the family twice, and while Resolve (or any app) is running Windows holds the file open,
    # so a copy over it fails -- which used to stop the whole install.
    $size = (Get-Item $src).Length
    $hash = (Get-FileHash $src).Hash
    $same = @(Get-ChildItem -Path @($dir, (Join-Path $env:WINDIR 'Fonts')) -File -ErrorAction SilentlyContinue |
        Where-Object { $_.Length -eq $size -and (Get-FileHash $_.FullName).Hash -eq $hash })
    if ($same.Count -gt 0) {
        Write-Host "$($fonts[$file]) is already installed ($($same[0].Name))" -ForegroundColor Green
        continue
    }
    try {
        Copy-Item -Path $src -Destination $dest -Force
    } catch {
        Write-Host "Could not update $file because it is in use. Close DaVinci Resolve and run the installer again." -ForegroundColor Yellow
        continue
    }
    New-ItemProperty -Path $reg -Name $fonts[$file] -Value $dest -PropertyType String -Force | Out-Null
    [void]$native::AddFontResourceW($dest)
    Write-Host "Installed $($fonts[$file])" -ForegroundColor Green
}
$result = [IntPtr]::Zero
[void]$native::SendMessageTimeout([IntPtr]0xFFFF, 0x001D, [IntPtr]::Zero, [IntPtr]::Zero, 2, 1000, [ref]$result)

# Resolve's font allow-list. While it is on, Fusion can only find the families named in
# the file it points at, so both families have to be listed there as well.
$cfg = Join-Path $env:APPDATA 'Blackmagic Design\DaVinci Resolve\Preferences\config.user.xml'
if (Test-Path $cfg) {
    $xml = Get-Content -Raw -Path $cfg
    if ($xml -match '<IsFontWhiteListEnabled>true</IsFontWhiteListEnabled>' -and
        $xml -match '<FontWhiteListFilePath>([^<]+)</FontWhiteListFilePath>') {
        $list = $Matches[1]
        if (Test-Path $list) { foreach ($family in @('Open Sans', 'Noto Color Emoji')) {
            $text = [IO.File]::ReadAllText($list)
            $names = $text -split "`r?`n" | ForEach-Object { $_.Trim() }
            if ($names -contains $family) {
                Write-Host "Your Resolve font list already includes $family."
            } else {
                $prefix = ''
                if ($text.Length -gt 0 -and -not $text.EndsWith("`n")) { $prefix = "`r`n" }
                [IO.File]::AppendAllText($list, "$prefix$family`r`n", (New-Object System.Text.UTF8Encoding $false))
                Write-Host "Added '$family' to your Resolve font list: $list" -ForegroundColor Green
            }
        } } else {
            Write-Host "Resolve's 'Display Only Specific Fonts' list was not found at $list -- add 'Open Sans' and 'Noto Color Emoji' to it yourself." -ForegroundColor Yellow
        }
    }
}
Write-Host ""
Write-Host "Now restart DaVinci Resolve." -ForegroundColor Cyan
