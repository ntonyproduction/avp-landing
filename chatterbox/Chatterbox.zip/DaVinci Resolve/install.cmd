@echo off
rem Double-click me. Installs the Chatterbox title and its emoji font for the
rem current user (no admin), then tells you to restart DaVinci Resolve.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
echo.
pause
