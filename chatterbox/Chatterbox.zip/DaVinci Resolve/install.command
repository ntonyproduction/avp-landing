#!/bin/bash
# Chatterbox -- installer for DaVinci Resolve (free or Studio) on macOS, current user only.
# No administrator password needed. Double-click it; if macOS says it cannot be opened,
# Control-click it, choose Open, then Open again.
#
# 1. Copies the title template into Resolve's Fusion template folder.
# 2. Copies the title's control panel, a Fuse (fuse/AVP_Chatterbox.fuse), into Resolve's
#    Fuses folder -- the title does not load without it.
# 3. Installs the fonts the cards use into ~/Library/Fonts: Open Sans, and Noto Color Emoji,
#    which Text+ switches to for every emoji (without it a card with an emoji goes black).
#    If Resolve's "Display Only Specific Fonts" list is on, both families are added to it.
#
# Then quit and reopen DaVinci Resolve -- it reads templates, fuses and fonts when it launches.
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
SUPPORT="$HOME/Library/Application Support/Blackmagic Design/DaVinci Resolve"
FUSION="$SUPPORT/Fusion"

if [ ! -d "$HERE/Edit" ] || [ ! -f "$HERE/fuse/AVP_Chatterbox.fuse" ]; then
    echo "The Edit and fuse folders must sit next to this installer. Extract the whole download first."
    exit 1
fi
if [ ! -d "$SUPPORT" ]; then
    echo "DaVinci Resolve's support folder was not found at: $SUPPORT"
    echo "Open DaVinci Resolve once, quit it, and run this installer again."
    exit 1
fi

# templates, merged into any Edit folder already there
mkdir -p "$FUSION/Templates"
( cd "$HERE" && find Edit -type f ) | while IFS= read -r rel; do
    mkdir -p "$FUSION/Templates/$(dirname "$rel")"
    cp -f "$HERE/$rel" "$FUSION/Templates/$rel"
    echo "Installed $FUSION/Templates/$rel"
done

mkdir -p "$FUSION/Fuses/AVP"
cp -f "$HERE/fuse/AVP_Chatterbox.fuse" "$FUSION/Fuses/AVP/AVP_Chatterbox.fuse"
echo "Installed $FUSION/Fuses/AVP/AVP_Chatterbox.fuse"

# Before 0.22 the tool was called Comment Generator: set its template aside, not deleted.
LEGACY="$FUSION/Templates/Edit/Titles/Audio Vision Productions/Comment Generator.setting"
if [ -f "$LEGACY" ]; then
    mv -f "$LEGACY" "$LEGACY.old"
    echo "Set aside the old Comment Generator template as $LEGACY.old"
fi

mkdir -p "$HOME/Library/Fonts"
for f in OpenSans.ttf Noto-COLRv1.ttf; do
    cp -f "$HERE/fonts/$f" "$HOME/Library/Fonts/$f"
    echo "Installed font $f"
done

# Resolve's font allow-list: while it is on, Fusion only finds the families named in its file.
for CFG in "$HOME/Library/Preferences/Blackmagic Design/DaVinci Resolve/config.user.xml" \
           "/Library/Preferences/Blackmagic Design/DaVinci Resolve/config.user.xml"; do
    [ -f "$CFG" ] || continue
    grep -q "<IsFontWhiteListEnabled>true</IsFontWhiteListEnabled>" "$CFG" || continue
    LIST="$(sed -n 's:.*<FontWhiteListFilePath>\(.*\)</FontWhiteListFilePath>.*:\1:p' "$CFG" | head -n 1)"
    if [ -z "$LIST" ] || [ ! -f "$LIST" ]; then
        echo "Resolve's Display Only Specific Fonts list was not found -- add Open Sans and Noto Color Emoji to it yourself."
        continue
    fi
    for FAMILY in "Open Sans" "Noto Color Emoji"; do
        if grep -qxF "$FAMILY" <(tr -d '\r' < "$LIST"); then
            echo "Your Resolve font list already includes $FAMILY."
        else
            [ -n "$(tail -c 1 "$LIST")" ] && printf '\n' >> "$LIST"
            printf '%s\n' "$FAMILY" >> "$LIST"
            echo "Added $FAMILY to your Resolve font list: $LIST"
        fi
    done
done

echo
echo "Done. Quit and reopen DaVinci Resolve, then find Chatterbox under"
echo "Effects > Toolbox > Titles > Audio Vision Productions."
