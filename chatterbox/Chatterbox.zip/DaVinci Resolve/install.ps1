<#
    Chatterbox -- installer for DaVinci Resolve (free or Studio), current user only.
    No administrator rights required.

    1. Copies the title template into Resolve's Fusion template folder.
    2. Copies the title's control panel, a Fuse (fuse\AVP_Chatterbox.fuse), into Resolve's
       Fuses folder -- the title does not load without it.
    3. Installs the fonts the template needs -- Open Sans and Noto Color Emoji, per user -- and
       adds them to Resolve's font allow-list if you use one (that part is fonts\install-fonts.ps1).

    The font is not optional: Text+ switches to "Noto Color Emoji" for every emoji glyph and
    fails without it, which takes the whole card with it. So this script does all three.

    Then RESTART DaVinci Resolve -- it reads templates, fuses and fonts when it launches -- and find
    the card under Effects > Titles > Audio Vision Productions > Chatterbox.
#>
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$src  = Join-Path $here 'Edit'
$dest = Join-Path $env:APPDATA 'Blackmagic Design\DaVinci Resolve\Support\Fusion\Templates\Edit'

$fuse    = Join-Path $here 'fuse\AVP_Chatterbox.fuse'
$fuseDir = Join-Path $env:APPDATA 'Blackmagic Design\DaVinci Resolve\Support\Fusion\Fuses\AVP'
if (-not (Test-Path $src)) { throw "The Edit folder is missing next to this script." }
if (-not (Test-Path $fuse)) { throw "fuse\AVP_Chatterbox.fuse is missing next to this script." }
if (-not (Test-Path (Join-Path $env:APPDATA 'Blackmagic Design\DaVinci Resolve'))) {
    Write-Host "DaVinci Resolve's support folder was not found under $env:APPDATA. Is Resolve installed for this user?" -ForegroundColor Yellow
}

# File by file, so an existing Templates\Edit is merged into rather than nested under.
Get-ChildItem -Path $src -Recurse -File | ForEach-Object {
    $rel = $_.FullName.Substring($src.Length + 1)
    $to  = Join-Path $dest $rel
    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $to) | Out-Null
    Copy-Item -Path $_.FullName -Destination $to -Force
    Write-Host "Installed $to" -ForegroundColor Green
}

New-Item -ItemType Directory -Force -Path $fuseDir | Out-Null
Copy-Item -Path $fuse -Destination (Join-Path $fuseDir 'AVP_Chatterbox.fuse') -Force
Write-Host "Installed $fuseDir\AVP_Chatterbox.fuse" -ForegroundColor Green

# Before 0.22 the tool was called Comment Generator. Set its template aside so the Effects
# Library lists Chatterbox only -- renamed, not deleted, and Resolve reads only *.setting
# files. Its hidden control panel, AVP_CommentHub.fuse, stays, so titles already placed in
# older projects still open.
$legacy = Join-Path $dest 'Titles\Audio Vision Productions\Comment Generator.setting'
if (Test-Path $legacy) {
    Move-Item -Path $legacy -Destination ($legacy + '.old') -Force
    Write-Host "Set aside the old Comment Generator template as $legacy.old" -ForegroundColor Yellow
}

& (Join-Path $here 'fonts\install-fonts.ps1')
