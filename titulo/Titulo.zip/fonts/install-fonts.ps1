<#
    Titulo -- installs the pack's fonts for the current user only. No administrator rights needed.
    Right-click this file > Run with PowerShell. Then RESTART DaVinci Resolve and Premiere Pro: both
    read the font list when they launch.

    Every .ttf beside this script is installed: the families the titles default to (Montserrat,
    Inter, Playfair Display, Pinyon Script, Allura, Mrs Saint Delafield, Pathway Gothic One, Archivo Black, and since 0.7 Italiana, Tilt Neon, Doto, Fredoka) and
    Noto Color Emoji, which Text+ switches to for every emoji glyph and fails without (the title goes black).
    All of them are under the SIL Open Font License; the licence files sit beside them.

    If Resolve's optional font allow-list is on (Preferences > User > Editing > Text > Display Only
    Specific Fonts), the family names are appended to the list file that Resolve's preferences name,
    as Chatterbox's installer does.

    Remove later from Settings > Personalisation > Fonts.

    For a test only: -Target <folder> copies the fonts into that folder and leaves the registry, the
    session's fonts and the real Resolve preferences alone (it says what it would have registered).
    -ResolvePrefs <config.user.xml> reads Resolve's allow-list setting from that file instead.
#>
param(
    [string]$Target = '',
    [string]$ResolvePrefs = ''
)
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$test = $Target -ne ''
if ($test) {
    $dir = $Target
    Write-Host "TEST RUN: fonts go to $dir. The registry and the session's fonts are not touched." -ForegroundColor Yellow
} else {
    $dir = Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\Fonts'
}
$reg = 'HKCU:\Software\Microsoft\Windows NT\CurrentVersion\Fonts'
New-Item -ItemType Directory -Force -Path $dir | Out-Null

if (-not $test) {
    if (-not (Test-Path $reg)) { New-Item -Path $reg -Force | Out-Null }
    # Registering a font is two steps: the registry entry makes it permanent, and AddFontResource loads
    # it into the current session so apps started from now on see it. The Fonts settings page does both.
    $sig = @'
[DllImport("gdi32.dll", CharSet = CharSet.Unicode)] public static extern int AddFontResourceW(string lpszFilename);
[DllImport("user32.dll")] public static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam, uint fuFlags, uint uTimeout, out IntPtr lpdwResult);
'@
    Add-Type -MemberDefinition $sig -Name Gdi -Namespace TituloFonts
}

$families = @{}
$installed = 0; $present = 0; $failed = 0
foreach ($font in (Get-ChildItem -Path $here -Filter '*.ttf' | Sort-Object Name)) {
    $to = Join-Path $dir $font.Name
    $families[(($font.BaseName -split '-')[0] -replace '\[.*\]', '')] = $true
    if ((Test-Path $to) -and ((Get-Item $to).Length -eq $font.Length) -and
        ((Get-FileHash $to).Hash -eq (Get-FileHash $font.FullName).Hash)) {
        # the same file is already there (an earlier run, or Chatterbox's identical emoji font)
        Write-Host "Already installed $($font.Name)" -ForegroundColor DarkGray
        $present++
    } else {
        # An older copy held open by a running app cannot be overwritten. Before this catch, that error
        # stopped the whole install half-way, and the fonts after it were never copied.
        try {
            Copy-Item -Path $font.FullName -Destination $to -Force
        } catch {
            Write-Host "Could not install $($font.Name) ($($_.Exception.Message)). If DaVinci Resolve or Premiere Pro is open, close it and run this again." -ForegroundColor Yellow
            $failed++
            continue
        }
        Write-Host "Installed $($font.Name)" -ForegroundColor Green
        $installed++
    }
    # the registry value name is what the Fonts panel shows; the file name is close enough and unique
    $label = ($font.BaseName -replace '\[.*\]', '') + ' (TrueType)'
    if ($test) {
        Write-Host "  (test) would register '$label' = $to"
    } else {
        New-ItemProperty -Path $reg -Name $label -Value $to -PropertyType String -Force | Out-Null
        [void][TituloFonts.Gdi]::AddFontResourceW($to)
    }
}
if (-not $test) {
    $HWND_BROADCAST = [IntPtr]0xffff; $WM_FONTCHANGE = 0x001D; $result = [IntPtr]::Zero
    [void][TituloFonts.Gdi]::SendMessageTimeout($HWND_BROADCAST, $WM_FONTCHANGE, [IntPtr]::Zero, [IntPtr]::Zero, 2, 1000, [ref]$result)
}

# Resolve's font allow-list. While it is on, Fusion only finds the families named in the file that
# Resolve's preferences point at, so every family has to be listed there too. The setting and the
# file's path are in config.user.xml (the same keys Chatterbox reads); there is no fixed list file.
if ($ResolvePrefs -ne '') {
    $cfg = $ResolvePrefs
} elseif ($test) {
    $cfg = ''
    Write-Host "  (test) Resolve's real font list was not looked at."
} else {
    $cfg = Join-Path $env:APPDATA 'Blackmagic Design\DaVinci Resolve\Preferences\config.user.xml'
}
if ($cfg -ne '' -and (Test-Path $cfg)) {
    $xml = Get-Content -Raw -Path $cfg
    if ($xml -match '<IsFontWhiteListEnabled>true</IsFontWhiteListEnabled>') {
        $names = foreach ($fam in ($families.Keys | Sort-Object)) {
            switch ($fam) { 'PlayfairDisplay' { 'Playfair Display' } 'PinyonScript' { 'Pinyon Script' }
                            'MrsSaintDelafield' { 'Mrs Saint Delafield' } 'PathwayGothicOne' { 'Pathway Gothic One' }
                            'ArchivoBlack' { 'Archivo Black' } 'TiltNeon' { 'Tilt Neon' } 'CourierPrime' { 'Courier Prime' } 'PressStart2P' { 'Press Start 2P' } 'TituloInter' { 'Titulo Inter' } 'Noto' { 'Noto Color Emoji' } default { $fam } }
        }
        $list = ''
        if ($xml -match '<FontWhiteListFilePath>([^<]+)</FontWhiteListFilePath>') { $list = $Matches[1] }
        if ($list -ne '' -and (Test-Path $list)) {
            foreach ($name in $names) {
                $text = [IO.File]::ReadAllText($list)
                $have = $text -split "`r?`n" | ForEach-Object { $_.Trim() }
                if ($have -contains $name) {
                    Write-Host "Your Resolve font list already includes $name."
                } else {
                    $prefix = ''
                    if ($text.Length -gt 0 -and -not $text.EndsWith("`n")) { $prefix = "`r`n" }
                    [IO.File]::AppendAllText($list, "$prefix$name`r`n", (New-Object System.Text.UTF8Encoding $false))
                    Write-Host "Added $name to your Resolve font list: $list" -ForegroundColor Green
                }
            }
        } else {
            Write-Host "Resolve's Display Only Specific Fonts is on, but its list file was not found. Add these to it yourself: $($names -join ', ')" -ForegroundColor Yellow
        }
    }
}

Write-Host ""
Write-Host "$installed installed, $present already there, $failed could not be installed."
Write-Host "Done. Restart DaVinci Resolve and Premiere Pro." -ForegroundColor Cyan
