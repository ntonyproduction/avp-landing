@echo off
rem Titulo installer for Windows. Double-click me. Current user only, no administrator rights needed.
rem It installs the fonts, puts the titles in DaVinci Resolve and the templates in Premiere Pro
rem (install.ps1 beside me does the work), then asks you to restart both.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
echo.
pause
