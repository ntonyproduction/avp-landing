#!/bin/bash
# Titulo -- installer for macOS, current user only. No administrator password needed.
# Double-click it. If macOS will not open it, READ ME FIRST.txt has the way through
# (System Settings > Privacy & Security > Open Anyway).
#
# 1. Fonts: the 15 font files from fonts/ into ~/Library/Fonts. A font file already there under the
#    same name is left as it is. If Resolve's "Display Only Specific Fonts" list is on, the families
#    are added to it.
# 2. DaVinci Resolve (free or Studio): every title in the pack, each with its library icon, into
#    ~/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/Templates/
#    Edit/Titles/Audio Vision Productions/Titulo. An older Titulo folder there is deleted first, and so
#    is an older Titulo.drfx or Titulo Pro.drfx in the Templates folder, so no title lists twice.
# 3. Premiere Pro: every template (.mogrt) in the pack into
#    ~/Library/Application Support/Adobe/Common/Motion Graphics Templates. A file there with a Titulo
#    name is replaced only when it is an older Titulo (its definition.json names "AVP Titulo ...");
#    anyone else's file is left as it is and reported as a PROBLEM. A pack with no Premiere Pro folder skips this.
# Every count it prints comes from the pack itself, never from a number written here.
# Nothing else is changed or deleted. Then quit and reopen DaVinci Resolve and Premiere Pro.
# Every PROBLEM line is printed again at the end, so a run with one never ends on "Done".
#
# Built from chatterbox/install.command (the Templates folder, the fonts and the font list).
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC_RESOLVE="$HERE/DaVinci Resolve"
SRC_PREMIERE="$HERE/Premiere Pro"
PACK="Edit/Titles/Audio Vision Productions/Titulo"
PROBLEMS=0
PROBLEM_LINES=""

problem() {
    echo "  PROBLEM: $1"
    PROBLEMS=$((PROBLEMS + 1))
    PROBLEM_LINES="$PROBLEM_LINES  PROBLEM: $1
"
}

# A .mogrt is a zip; Titulo's definition.json names it "AVP Titulo <Name>". unzip and grep are stock macOS.
is_titulo_mogrt() {
    unzip -p "$1" definition.json 2>/dev/null | grep -q '"capsuleName"[[:space:]]*:[[:space:]]*"AVP Titulo '
}

if [ ! -d "$HERE/fonts" ] || [ ! -d "$SRC_RESOLVE/$PACK" ]; then
    echo "The fonts and DaVinci Resolve folders must sit next to this installer."
    echo "Unzip the whole download first, then run install.command from the unzipped folder."
    exit 1
fi
# What the pack holds, counted from its own files, so the counts below follow the pack.
R_ALL="$(ls "$SRC_RESOLVE/$PACK" | grep -c '\.setting$')"
I_ALL="$(ls "$SRC_RESOLVE/$PACK" | grep -c '\.png$')"
P_ALL=0
[ -d "$SRC_PREMIERE" ] && P_ALL="$(ls "$SRC_PREMIERE" | grep -c '\.mogrt$')"

echo "Titulo installer"
echo "Mac: macOS $(sw_vers -productVersion 2>/dev/null || echo 'version not read')"
# The editors' versions, read from the apps, so the tester does not have to look them up.
for APP in "/Applications/DaVinci Resolve"*/"DaVinci Resolve"*.app "/Applications/DaVinci Resolve"*.app \
           "/Applications/Adobe Premiere Pro"*/"Adobe Premiere Pro"*.app; do
    [ -d "$APP" ] || continue
    VER="$(defaults read "$APP/Contents/Info" CFBundleShortVersionString 2>/dev/null || echo '?')"
    BID="$(defaults read "$APP/Contents/Info" CFBundleIdentifier 2>/dev/null || echo '?')"
    echo "Found: $(basename "$APP" .app) $VER ($BID)"
done
echo

# ---- 1. Fonts ---------------------------------------------------------------------------------
FONTS="$HOME/Library/Fonts"
mkdir -p "$FONTS" || problem "could not make $FONTS"
echo "Fonts, into $FONTS:"
F_NEW=0; F_HAVE=0
for SRC in "$HERE"/fonts/*.ttf; do
    NAME="$(basename "$SRC")"
    if [ -f "$FONTS/$NAME" ]; then
        if cmp -s "$SRC" "$FONTS/$NAME"; then
            echo "  already installed, skipped: $NAME"
        else
            echo "  skipped: $NAME. A different file with this name is already installed, so it was left as it is."
        fi
        F_HAVE=$((F_HAVE + 1))
    elif [ -f "/Library/Fonts/$NAME" ]; then
        echo "  already installed for every user (/Library/Fonts), skipped: $NAME"
        F_HAVE=$((F_HAVE + 1))
    elif cp "$SRC" "$FONTS/$NAME"; then
        echo "  installed: $NAME"
        F_NEW=$((F_NEW + 1))
    else
        problem "could not copy $NAME"
    fi
done
echo "  $F_NEW installed, $F_HAVE already there."

# Resolve's font allow-list: while it is on, Fusion only finds the families named in its file.
for CFG in "$HOME/Library/Preferences/Blackmagic Design/DaVinci Resolve/config.user.xml" \
           "/Library/Preferences/Blackmagic Design/DaVinci Resolve/config.user.xml"; do
    [ -f "$CFG" ] || continue
    grep -q "<IsFontWhiteListEnabled>true</IsFontWhiteListEnabled>" "$CFG" || continue
    LIST="$(sed -n 's:.*<FontWhiteListFilePath>\(.*\)</FontWhiteListFilePath>.*:\1:p' "$CFG" | head -n 1)"
    if [ -z "$LIST" ] || [ ! -f "$LIST" ]; then
        echo "  Resolve's Display Only Specific Fonts is on, but its list was not found. Add these families to it yourself:"
        echo "  Montserrat, Inter, Titulo Inter, Playfair Display, Pinyon Script, Allura, Mrs Saint Delafield, Pathway Gothic One, Archivo Black, Italiana, Tilt Neon, Doto, Fredoka, Courier Prime, Press Start 2P, Anton, Noto Color Emoji"
        continue
    fi
    for FAMILY in "Montserrat" "Inter" "Titulo Inter" "Playfair Display" "Pinyon Script" "Allura" "Mrs Saint Delafield" \
                  "Pathway Gothic One" "Archivo Black" "Italiana" "Tilt Neon" "Doto" "Fredoka" "Courier Prime" "Press Start 2P" "Anton" "Noto Color Emoji"; do
        if grep -qxF "$FAMILY" <(tr -d '\r' < "$LIST"); then
            echo "  Your Resolve font list already includes $FAMILY."
        else
            [ -n "$(tail -c 1 "$LIST")" ] && printf '\n' >> "$LIST"
            printf '%s\n' "$FAMILY" >> "$LIST" && echo "  Added $FAMILY to your Resolve font list: $LIST"
        fi
    done
done
echo

# ---- 2. DaVinci Resolve -------------------------------------------------------------------------
RESOLVE="$HOME/Library/Application Support/Blackmagic Design/DaVinci Resolve"
TEMPLATES="$RESOLVE/Fusion/Templates"
DEST="$TEMPLATES/$PACK"
echo "DaVinci Resolve:"
if [ ! -d "$RESOLVE" ]; then
    problem "Resolve's folder was not found, so the Resolve titles were not installed: $RESOLVE"
    echo "  If DaVinci Resolve is on this Mac, open it once, quit it, and run this installer again."
else
    # A Titulo bundle installed by a double-click would list every title a second time.
    while IFS= read -r OLD; do
        [ -n "$OLD" ] || continue
        if rm -f "$OLD"; then
            echo "  deleted an older Titulo bundle: $OLD"
        else
            problem "could not delete the older bundle $OLD"
        fi
    done < <(find "$TEMPLATES" -maxdepth 2 -type f \( -name "Titulo.drfx" -o -name "Titulo Pro.drfx" \) 2>/dev/null)
    # Resolve sees new files only when the folder itself changes, so the old folder goes and a new one comes.
    case "$DEST" in
        */"Audio Vision Productions/Titulo")
            if [ -d "$DEST" ]; then
                if rm -rf "$DEST"; then
                    echo "  deleted the older Titulo titles in $DEST, to replace them"
                else
                    problem "could not delete the older Titulo folder $DEST"
                fi
            fi ;;
    esac
    mkdir -p "$DEST" || problem "could not make $DEST"
    if cp "$SRC_RESOLVE/$PACK"/* "$DEST/"; then
        echo "  installed $(ls "$DEST" | grep -c '\.setting$') titles and $(ls "$DEST" | grep -c '\.png$') icon files into:"
        echo "  $DEST"
    else
        problem "could not copy the titles into $DEST"
    fi
fi
echo

# ---- 3. Premiere Pro ----------------------------------------------------------------------------
MGT="$HOME/Library/Application Support/Adobe/Common/Motion Graphics Templates"
P_NEW=0; P_SAME=0; P_REPL=0; P_LEFT=0
if [ "$P_ALL" -eq 0 ]; then
    echo "Premiere Pro: this pack has no Premiere templates, so nothing was installed for Premiere."
else
echo "Premiere Pro, into $MGT:"
mkdir -p "$MGT" || problem "could not make $MGT"
for SRC in "$SRC_PREMIERE"/*.mogrt; do
    NAME="$(basename "$SRC")"
    if [ -f "$MGT/$NAME" ] && cmp -s "$SRC" "$MGT/$NAME"; then
        echo "  already installed, same file: $NAME"
        P_SAME=$((P_SAME + 1))
    elif [ -e "$MGT/$NAME" ] && ! is_titulo_mogrt "$MGT/$NAME"; then
        problem "left as it is: $MGT/$NAME is not a Titulo template, so Titulo's $NAME was not installed"
        P_LEFT=$((P_LEFT + 1))
    elif [ -f "$MGT/$NAME" ]; then
        if cp -f "$SRC" "$MGT/$NAME"; then
            echo "  replaced the older Titulo copy: $NAME"
            P_REPL=$((P_REPL + 1))
        else
            problem "could not replace $NAME"
        fi
    elif cp "$SRC" "$MGT/$NAME"; then
        echo "  installed: $NAME"
        P_NEW=$((P_NEW + 1))
    else
        problem "could not copy $NAME"
    fi
done
echo "  $P_NEW installed, $P_REPL replaced, $P_SAME already there, $P_LEFT left as they were (not Titulo's)."
fi
echo

# ---- Check --------------------------------------------------------------------------------------
F_OK=0; F_ALL=0; F_OTHER=""
for SRC in "$HERE"/fonts/*.ttf; do
    F_ALL=$((F_ALL + 1))
    NAME="$(basename "$SRC")"
    if cmp -s "$SRC" "$FONTS/$NAME" 2>/dev/null || cmp -s "$SRC" "/Library/Fonts/$NAME" 2>/dev/null; then
        F_OK=$((F_OK + 1))
    elif [ -f "$FONTS/$NAME" ] || [ -f "/Library/Fonts/$NAME" ]; then
        F_OTHER="$F_OTHER $NAME"
    fi
done
[ -n "$F_OTHER" ] && echo "Note: a different file with the same name is installed for:$F_OTHER. Titles using it may look a little different."
# Resolve: each title and icon file of the pack, byte for byte in the installed folder.
R_OK=0; I_OK=0
for SRC in "$SRC_RESOLVE/$PACK"/*; do
    cmp -s "$SRC" "$DEST/$(basename "$SRC")" 2>/dev/null || continue
    case "$SRC" in
        *.setting) R_OK=$((R_OK + 1)) ;;
        *.png) I_OK=$((I_OK + 1)) ;;
    esac
done
P_OK=0
if [ "$P_ALL" -gt 0 ]; then
    for SRC in "$SRC_PREMIERE"/*.mogrt; do
        cmp -s "$SRC" "$MGT/$(basename "$SRC")" 2>/dev/null && P_OK=$((P_OK + 1))
    done
fi
echo "Check: Titulo's fonts $F_OK of $F_ALL in place. Resolve titles: $R_OK of $R_ALL ($I_OK of $I_ALL icon files). Premiere templates: $P_OK of $P_ALL."
if [ "$PROBLEMS" -gt 0 ]; then
    echo
    echo "$PROBLEMS problem(s):"
    printf '%s' "$PROBLEM_LINES"
    if [ -f "$HERE/READ ME FIRST.txt" ]; then
        echo "Please send this whole window's text to Anthony."
    else
        echo "Please send this whole window's text to hello@audiovisionproductions.ca."
    fi
    echo
    exit 1
fi
if [ -f "$HERE/READ ME FIRST.txt" ]; then
    echo "Done. Quit and reopen DaVinci Resolve and Premiere Pro, then go back to READ ME FIRST.txt."
else
    echo "Done. Quit and reopen DaVinci Resolve and Premiere Pro."
fi
echo
