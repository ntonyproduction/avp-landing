<#
    Titulo -- installer for Windows, current user only. No administrator rights needed.
    Started by install.cmd (double-click that one). The Windows twin of install.command.

    1. Fonts: fonts\install-fonts.ps1 installs every .ttf in fonts\ for this user and, if Resolve's
       "Display Only Specific Fonts" list is on, adds the families to it.
    2. DaVinci Resolve (free or Studio): every title in the pack, each with its library icon, into
       %APPDATA%\Blackmagic Design\DaVinci Resolve\Support\Fusion\Templates\
       Edit\Titles\Audio Vision Productions\Titulo. An older Titulo folder there is deleted first, and so
       is an older Titulo.drfx or Titulo Pro.drfx in the Templates folder, so no title lists twice.
    3. Premiere Pro: every template (.mogrt) in the pack into
       %APPDATA%\Adobe\Common\Motion Graphics Templates. A file there with a Titulo name is replaced only
       when it is an older Titulo (its definition.json names "AVP Titulo ..."); anyone else's file is left
       as it is and reported as a PROBLEM.
    Every count it prints comes from the pack itself. Nothing else is changed or deleted.
    Then restart DaVinci Resolve and Premiere Pro. Every PROBLEM line is printed again at the end.

    Built from chatterbox/install.ps1 and titulo/install/install.command. Plain ASCII on purpose:
    Windows PowerShell 5 reads a script without a byte-order mark in the system code page.
#>
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$pack = 'Edit\Titles\Audio Vision Productions\Titulo'
$srcResolve = Join-Path (Join-Path $here 'DaVinci Resolve') $pack
$srcPremiere = Join-Path $here 'Premiere Pro'
$fontScript = Join-Path $here 'fonts\install-fonts.ps1'
$script:problems = New-Object System.Collections.Generic.List[string]
function Problem([string]$msg) {
    Write-Host "  PROBLEM: $msg" -ForegroundColor Red
    $script:problems.Add($msg)
}
function SameFile([string]$a, [string]$b) {
    if (-not (Test-Path -LiteralPath $b)) { return $false }
    if ((Get-Item -LiteralPath $a).Length -ne (Get-Item -LiteralPath $b).Length) { return $false }
    return (Get-FileHash -LiteralPath $a).Hash -eq (Get-FileHash -LiteralPath $b).Hash
}
Add-Type -AssemblyName System.IO.Compression.FileSystem
# A .mogrt is a zip; Titulo's definition.json names it "AVP Titulo <Name>".
function IsTituloMogrt([string]$path) {
    try {
        $zip = [IO.Compression.ZipFile]::OpenRead($path)
        try {
            $entry = $zip.GetEntry('definition.json')
            if ($null -eq $entry) { return $false }
            $reader = New-Object IO.StreamReader($entry.Open())
            try { $text = $reader.ReadToEnd() } finally { $reader.Dispose() }
            return $text -match '"capsuleName"\s*:\s*"AVP Titulo '
        } finally { $zip.Dispose() }
    } catch { return $false }
}

if (-not (Test-Path -LiteralPath $fontScript) -or -not (Test-Path -LiteralPath $srcResolve)) {
    Write-Host "The fonts and DaVinci Resolve folders must sit next to this installer."
    Write-Host "Unzip the whole download first (right-click the zip > Extract All), then double-click install.cmd in the unzipped folder."
    exit 1
}
$rAll = @(Get-ChildItem -LiteralPath $srcResolve -Filter '*.setting').Count
$iAll = @(Get-ChildItem -LiteralPath $srcResolve -Filter '*.png').Count
$pAll = 0
if (Test-Path -LiteralPath $srcPremiere) { $pAll = @(Get-ChildItem -LiteralPath $srcPremiere -Filter '*.mogrt').Count }

Write-Host "Titulo installer"
Write-Host ""

# ---- 1. Fonts ------------------------------------------------------------------------------------
Write-Host "Fonts:"
try {
    & $fontScript
} catch {
    Problem "the fonts were not all installed ($($_.Exception.Message)). Close DaVinci Resolve and Premiere Pro and run this again."
}
Write-Host ""

# ---- 2. DaVinci Resolve --------------------------------------------------------------------------
$resolve = Join-Path $env:APPDATA 'Blackmagic Design\DaVinci Resolve\Support'
$templates = Join-Path $resolve 'Fusion\Templates'
$dest = Join-Path $templates $pack
Write-Host "DaVinci Resolve:"
if (-not (Test-Path -LiteralPath $resolve)) {
    Problem "Resolve's folder was not found, so the Resolve titles were not installed: $resolve"
    Write-Host "  If DaVinci Resolve is on this computer, open it once, close it, and run this installer again."
} else {
    # A Titulo bundle installed by a double-click or a drag would list every title a second time.
    if (Test-Path -LiteralPath $templates) {
        Get-ChildItem -LiteralPath $templates -Recurse -Depth 1 -File -ErrorAction SilentlyContinue |
            Where-Object { $_.Name -eq 'Titulo.drfx' -or $_.Name -eq 'Titulo Pro.drfx' } | ForEach-Object {
                try {
                    Remove-Item -LiteralPath $_.FullName -Force
                    Write-Host "  deleted an older Titulo bundle: $($_.FullName)"
                } catch { Problem "could not delete the older bundle $($_.FullName). Close DaVinci Resolve and run this again." }
            }
    }
    # Resolve sees new files only when the folder itself changes, so the old folder goes and a new one comes.
    if ((Test-Path -LiteralPath $dest) -and $dest.EndsWith('\Audio Vision Productions\Titulo')) {
        try {
            Remove-Item -LiteralPath $dest -Recurse -Force
            Write-Host "  deleted the older Titulo titles in $dest, to replace them"
        } catch { Problem "could not delete the older Titulo folder $dest. Close DaVinci Resolve and run this again." }
    }
    try {
        New-Item -ItemType Directory -Force -Path $dest | Out-Null
        Get-ChildItem -LiteralPath $srcResolve -File | ForEach-Object {
            Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $dest $_.Name) -Force
        }
        $n = @(Get-ChildItem -LiteralPath $dest -Filter '*.setting').Count
        $m = @(Get-ChildItem -LiteralPath $dest -Filter '*.png').Count
        Write-Host "  installed $n titles and $m icon files into:" -ForegroundColor Green
        Write-Host "  $dest"
    } catch { Problem "could not copy the titles into $dest ($($_.Exception.Message))" }
}
Write-Host ""

# ---- 3. Premiere Pro -----------------------------------------------------------------------------
$mgt = Join-Path $env:APPDATA 'Adobe\Common\Motion Graphics Templates'
$pNew = 0; $pSame = 0; $pRepl = 0; $pLeft = 0
if ($pAll -eq 0) {
    Write-Host "Premiere Pro: this pack has no Premiere templates, so nothing was installed for Premiere."
} else {
    Write-Host "Premiere Pro, into ${mgt}:"
    New-Item -ItemType Directory -Force -Path $mgt | Out-Null
    foreach ($src in (Get-ChildItem -LiteralPath $srcPremiere -Filter '*.mogrt' | Sort-Object Name)) {
        $to = Join-Path $mgt $src.Name
        if (SameFile $src.FullName $to) {
            $pSame++
        } elseif ((Test-Path -LiteralPath $to) -and -not (IsTituloMogrt $to)) {
            Problem "left as it is: $to is not a Titulo template, so Titulo's $($src.Name) was not installed"
            $pLeft++
        } else {
            $existed = Test-Path -LiteralPath $to
            try {
                Copy-Item -LiteralPath $src.FullName -Destination $to -Force
                if ($existed) { $pRepl++ } else { $pNew++ }
            } catch { Problem "could not copy $($src.Name). Close Premiere Pro and run this again." }
        }
    }
    Write-Host "  $pNew installed, $pRepl replaced, $pSame already there, $pLeft left as they were (not Titulo's)." -ForegroundColor Green
}
Write-Host ""

# ---- Check ---------------------------------------------------------------------------------------
$rOk = 0; $iOk = 0
foreach ($src in (Get-ChildItem -LiteralPath $srcResolve -File)) {
    if (SameFile $src.FullName (Join-Path $dest $src.Name)) {
        if ($src.Extension -eq '.setting') { $rOk++ } elseif ($src.Extension -eq '.png') { $iOk++ }
    }
}
$pOk = 0
if ($pAll -gt 0) {
    foreach ($src in (Get-ChildItem -LiteralPath $srcPremiere -Filter '*.mogrt')) {
        if (SameFile $src.FullName (Join-Path $mgt $src.Name)) { $pOk++ }
    }
}
Write-Host "Check: Resolve titles $rOk of $rAll ($iOk of $iAll icon files). Premiere templates $pOk of $pAll."
if ($script:problems.Count -gt 0) {
    Write-Host ""
    Write-Host "$($script:problems.Count) problem(s):" -ForegroundColor Red
    $script:problems | ForEach-Object { Write-Host "  PROBLEM: $_" -ForegroundColor Red }
    Write-Host "Please send this window's text to hello@audiovisionproductions.ca."
    exit 1
}
Write-Host "Done. Restart DaVinci Resolve and Premiere Pro. The titles are in Resolve under Effects > Titles >" -ForegroundColor Cyan
Write-Host "Audio Vision Productions > Titulo, and in Premiere under Essential Graphics > My Templates (search Titulo)." -ForegroundColor Cyan
